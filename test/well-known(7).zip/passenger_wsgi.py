import os
import sys



from link2scale.wsgi import application

