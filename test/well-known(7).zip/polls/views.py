from queue import Empty
from django.http import HttpResponseRedirect, HttpResponse, JsonResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from datetime import datetime
from .models import (
    index,
    category,
    Contact,
    Prperty,
    Propertyuser,
    CustomUser,
    database,
    Rating,
)

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.core.paginator import Paginator
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.contrib.auth.hashers import make_password
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


# admin functions_________________________________________________________________________________________________

# LOGIN AND AUTHENTICATION==============================================================


def admin_login(request):
    if request.method == "GET":
        context = ""
        return render(request, "admin/login.html", {"context": context})

    elif request.method == "POST":
        username = request.POST.get("username", "")
        password = request.POST.get("password", "")

        user = authenticate(request, username=username, password=password)
        if user is not None and user.is_superuser:
            login(request, user)
            return HttpResponseRedirect("dashboard/")

        elif user is not None and user.is_staff:
            login(request, user)
            return HttpResponseRedirect("dashboard/")

        else:
            context = {"error": "Please enter valid credentials"}  # to display error?
            return render(request, "admin/login.html", {"context": context})


def admin_logout(request):
    logout(request)
    return redirect("admin")


def dashboard(request):
    user = request.user

    if user.is_authenticated:
        is_superuser = user.is_superuser

    users = CustomUser.objects.filter(is_superuser=0)
    properties = Prperty.objects.all()
    index_count = index.objects.all()
    dbcount = database.objects.all().count()
    name = CustomUser.objects.filter(is_staff=1)
    approved_count = Prperty.objects.filter(is_admin=1).count()
    # print(is_superuser)
    # return HttpResponse(is_superuser)
    return render(
        request,
        "admin/AdminBase.html",
        {
            "users": users,
            "properties": properties,
            "index_count": index_count,
            "is_superuser": is_superuser,
            "dbcount": dbcount,
            "name": name,
            "approved_count": approved_count,
        },
    )


# INDEX====================================================================================
def ad_index(request):
    user = request.user

    if user.is_authenticated:
        is_superuser = user.is_superuser

    st = index.objects.all()
    for sin in st:
        count = category.objects.filter(index_id=sin.id)
        sin.cat_count = count.count()

    cat = category.objects.all()
    users = CustomUser.objects.filter(is_superuser=0)
    properties = Prperty.objects.all()
    index_count = index.objects.all()
    dbcount = database.objects.all().count()
    approved_count = Prperty.objects.filter(is_admin=1).count()
    return render(
        request,
        "admin/index/index.html",
        {
            "st": st,
            "cat": cat,
            "users": users,
            "properties": properties,
            "is_superuser": is_superuser,
            "count": count,
            "index_count": index_count,
            "dbcount": dbcount,
            "approved_count" : approved_count,
        },
    )


def ad_index_add(request):
    user = request.user

    if user.is_authenticated:
        is_superuser = user.is_superuser
    else:
        is_superuser = False

    index_count = index.objects.all()
    users = CustomUser.objects.filter(is_superuser=0)
    properties = Prperty.objects.all()
    dbcount = database.objects.all().count()
    approved_count = Prperty.objects.filter(is_admin=1).count()

    if request.method == "POST":
        name = request.POST.get("name")
        active = request.POST.get("active")
        image = request.FILES.get("image")

        if name and active and image:
            index.objects.create(
                name=name,
                active=active,
                image=image,
            )
            context = {"success": "Successfully submitted details !!"}
        else:
            context = {"error": "Missing form data."}

    else:
        context = {}

    return render(
        request,
        "admin/index/add.html",
        {
            "context": context,
            "is_superuser": is_superuser,
            "index_count": index_count,
            "users": users,
            "properties": properties,
            "dbcount": dbcount,
            "approved_count":approved_count,
        },
    )


def ad_index_edit(request, id):
    try:
        user = request.user

        if user.is_authenticated:
            is_superuser = user.is_superuser

        indexObj = index.objects.get(id=id)
        index_count = index.objects.all()
        users = CustomUser.objects.filter(is_superuser=0)
        properties = Prperty.objects.all()
        dbcount = database.objects.all().count()
        approved_count = Prperty.objects.filter(is_admin=1).count()
        if request.method == "POST":
            indexObj.name = request.POST["name"]
            indexObj.active = request.POST["active"]
            image = request.FILES.get("image")
            if image:
                indexObj.image = image
            indexObj.save()

            context = {"success": "Successfully updated details !!"}
            return render(
                request,
                "admin/index/edit.html",
                {
                    "context": context,
                    "indexObj": indexObj,
                    "is_superuser": is_superuser,
                    "users": users,
                    "properties": properties,
                    "index_count": index_count,
                    "dbcount": dbcount,
                    "approved_count" : approved_count,
                },
            )

        elif request.method == "GET":
            return render(
                request,
                "admin/index/edit.html",
                {
                    "indexObj": indexObj,
                    "is_superuser": is_superuser,
                    "users": users,
                    "properties": properties,
                    "index_count": index_count,
                    "dbcount": dbcount,
                    "approved_count" : approved_count,
                },
            )

    except index.DoesNotExist:
        context = {"error": "Data has not been submitted."}
        return render(
            request,
            "admin/index/edit.html",
            {
                "context": context,
                "is_superuser": is_superuser,
                "users": users,
                "properties": properties,
                "index_count": index_count,
                "dbcount": dbcount,
                "approved_count" : approved_count,
            },
        )


def ad_index_delete(request, id):
    record = get_object_or_404(index, id=id)
    record.delete()
    return JsonResponse({"success": "success"})

    return JsonResponse({"error": "error"})


# CATEGORY====================================================================================
def ad_category(request, id):
    user = request.user

    if user.is_authenticated:
        is_superuser = user.is_superuser

    cat = category.objects.filter(index_id=id)
    indexObj = index.objects.get(id=id)
    users = CustomUser.objects.filter(is_superuser=0)
    properties = Prperty.objects.all()
    index_count = index.objects.all()
    dbcount = database.objects.all().count()
    approved_count = Prperty.objects.filter(is_admin=1).count()
    return render(
        request,
        "admin/category/index.html",
        {
            "indexObj": indexObj,
            "cat": cat,
            "users": users,
            "properties": properties,
            "is_superuser": is_superuser,
            "index_count": index_count,
            "dbcount": dbcount,
            "approved_count":approved_count,
        },
    )


def ad_category_add(request, id):
    user = request.user

    if user.is_authenticated:
        is_superuser = user.is_superuser

    indexObj = index.objects.get(id=id)
    index_count = index.objects.all()
    properties = Prperty.objects.all()
    users = CustomUser.objects.filter(is_superuser=0)
    dbcount = database.objects.all().count()
    approved_count = Prperty.objects.filter(is_admin=1).count()

    if request.method == "POST":
        name = request.POST["name"]
        active = request.POST["active"]
        index_id = request.POST["index_id"]
        image = request.FILES["image"]

        category.objects.create(
            name=name, active=active, image=image, index_id=index_id
        )
        context = {"success": "Successfully submitted details !!"}
        return render(
            request,
            "admin/category/add.html",
            {
                "context": context,
                "indexObj": indexObj,
                "is_superuser": is_superuser,
                "index_count": index_count,
                "properties": properties,
                "users": users,
                "dbcount": dbcount,
                "approved_count": approved_count,
            },
        )

        context = {"error": "Data has not been submitted."}
        return render(
            request,
            "admin/category/add.html",
            {"context": context, "is_superuser": is_superuser},
        )

    elif request.method == "GET":
        context = ""
        return render(
            request,
            "admin/category/add.html",
            {
                "context": context,
                "indexObj": indexObj,
                "is_superuser": is_superuser,
                "index_count": index_count,
                "properties": properties,
                "users": users,
                "dbcount": dbcount,
                "approved_count": approved_count,
            },
        )


def ad_category_edit(request, id):
    user = request.user

    if user.is_authenticated:
        is_superuser = user.is_superuser

    cat = category.objects.get(id=id)
    indexObj = index.objects.filter(id=cat.index_id).first()
    index_count = index.objects.all()
    properties = Prperty.objects.all()
    users = CustomUser.objects.filter(is_superuser=0)
    dbcount = database.objects.all().count()
    approved_count = Prperty.objects.filter(is_admin=1).count()

    try:
        if request.method == "POST":
            cat.name = request.POST["name"]
            cat.active = request.POST["active"]
            image = request.FILES.get("image")
            if image:
                cat.image = image
            cat.save()

            context = {"success": "Successfully updated details !!"}
            return render(
                request,
                "admin/category/edit.html",
                {
                    "context": context,
                    "cat": cat,
                    "indexObj": indexObj,
                    "is_superuser": is_superuser,
                    "index_count": index_count,
                    "properties": properties,
                    "users": users,
                    "dbcount": dbcount,
                    "approved_count":approved_count,
                },
            )

        elif request.method == "GET":
            return render(
                request,
                "admin/category/edit.html",
                {
                    "cat": cat,
                    "indexObj": indexObj,
                    "is_superuser": is_superuser,
                    "index_count": index_count,
                    "properties": properties,
                    "users": users,
                    "dbcount": dbcount,
                    "approved_count":approved_count,
                },
            )

    except index.DoesNotExist:
        context = {"error": "Data has not been submitted."}
        return render(
            request,
            "admin/category/edit.html",
            {
                "context": context,
                "cat": cat,
                "indexObj": indexObj,
                "is_superuser": is_superuser,
                "index_count": index_count,
                "properties": properties,
                "users": users,
                "dbcount": dbcount,
                "approved_count": approved_count,
            },
        )


def ad_category_delete(request, id):
    record = get_object_or_404(category, id=id)
    record.delete()
    return JsonResponse({"success": "success"})

    return JsonResponse({"error": "error"})


# USER====================================================================================
def admin_user(request):
    user = request.user

    if user.is_authenticated:
        is_superuser = user.is_superuser

    users = CustomUser.objects.filter(is_superuser=0)
    properties = Prperty.objects.all()
    return render(
        request,
        "admin/user/user.html",
        {"users": users, "properties": properties, "is_superuser": is_superuser},
    )


def admin_user_add(request):
    user = request.user

    if user.is_authenticated:
        is_superuser = user.is_superuser

    users = CustomUser.objects.filter(is_superuser=0)
    index_count = index.objects.all()
    properties = Prperty.objects.all()
    dbcount = database.objects.all().count()
    approved_count = Prperty.objects.filter(is_admin=1).count()
    return render(
        request,
        "admin/user/add.html",
        {
            "users": users,
            "index_count": index_count,
            "properties": properties,
            "is_superuser": is_superuser,
            "dbcount": dbcount,
            "approved_count": approved_count,
        },
    )


# Property section==============================================================================


def viewproperties(request, id):
    user = request.user

    if user.is_authenticated:
        is_superuser = user.is_superuser

    properties = Prperty.objects.filter(id=id)
    users = CustomUser.objects.filter(is_superuser=0)
    return render(
        request,
        "admin/user/properties.html",
        {"properties": properties, "users": users, "is_superuser": is_superuser},
    )


def activate(request, id):
    property_obj = Prperty.objects.filter(id=id).update(is_admin="1")

    properties = Prperty.objects.all()
    users = CustomUser.objects.filter(is_superuser=0)
    return redirect("properties")


def deactivate(request, id):
    property_obj = Prperty.objects.filter(id=id).update(is_admin="0")
    users = CustomUser.objects.filter(is_superuser=0)
    properties = Prperty.objects.all()
    return redirect("properties")


def properties(request):
    properties_data = Propertyuser.objects.all().order_by("-id")
    properties = Prperty.objects.all()
    # latest_prop = reversed(list(Propertyuser.objects.all()))
    properties = Prperty.objects.all()
    users = CustomUser.objects.filter(is_superuser=0)
    index_count = index.objects.all()
    dbcount = database.objects.all().count()
    approved_count = Prperty.objects.filter(is_admin=1).count()


    for property in properties_data:
        prop = Prperty.objects.filter(user_id=property.id).first()
        count = Prperty.objects.filter(user_id=property.id).count()

        if prop is not None:
            property.property_id = prop.id
            property.property_count = count
        else:
            property.property_id = 0

    user = request.user
    is_superuser = user.is_authenticated and user.is_superuser

    page = request.GET.get("page", 1)
    properties_per_page = 50

    paginator = Paginator(properties_data, properties_per_page)

    try:
        properties_data = paginator.page(page)
    except PageNotAnInteger:
        properties_data = paginator.page(1)
    except EmptyPage:
        properties_data = paginator.page(paginator.num_pages)

    return render(
        request,
        "admin/property/property.html",
        {
            "properties_data": properties_data,
            "properties": properties,
            "users": users,
            "is_superuser": is_superuser,
            "index_count": index_count,
            "dbcount": dbcount,
            "approved_count" : approved_count,
        },
    )


# def properties(request):
#     property_users = Propertyuser.objects.all()

#     for property_user in property_users:
#         property_list = Prperty.objects.filter(user_id=property_user.id).first()
#         count = Prperty.objects.filter(user_id=property_user.id).count()

#         if property_list is not None:
#             id = property_list.id
#             property_user.property_id = id
#             property_user.property_count = count
#         else:
#             property_user.property_id = 0
#             property_user.property_count = 0

#     user = request.user

#     if user.is_authenticated:
#         is_superuser = user.is_superuser

#     page = request.GET.get("page", 1)  # Get the page parameter from the query string
#     properties_per_page = 10  # Number of properties to display per page

#     properties = Propertyuser.objects.all()

#     users = CustomUser.objects.filter(is_superuser=0)

#     # Paginate the properties based on the page parameter
#     paginator = Paginator(properties, properties_per_page)
#     try:
#         properties = paginator.page(page)
#     except PageNotAnInteger:
#         properties = paginator.page(1)
#     except EmptyPage:
#         properties = paginator.page(paginator.num_pages)

#     return render(
#         request,
#         "admin/property/property.html",
#         {"properties": properties, "users": users, "is_superuser": is_superuser},
#     )


def adminproperty(request):
    user = request.user

    if user.is_authenticated:
        is_superuser = user.is_superuser

    if request.method == "POST":
        index = request.POST.get("index", "")
        category = request.POST.get("category", "")  # Assign a value to category
        weburl = request.POST.get("weburl", "")
        address = request.POST.get("address", "")
        # title = request.POST.get('title', '')
        image = request.FILES["image"]
        purchase_type = request.POST.get("purchase_type", "")
        floor_area = request.POST.get("floor_area", "")
        property_type = request.POST.getlist("property_type", "")
        Bedroom = request.POST.get("Bedroom", "")
        bathroom = request.POST.get("bathroom", "")
        amenties = request.POST.getlist("amenties")
        features = request.POST.getlist("features")
        duration = request.POST.get("duration", "")
        amount = request.POST.get("amount", "")
        floor_area_value = request.POST.get("floor_area_value", "")
        site_area = request.POST.get("site_area", "")
        site_area_value = request.POST.get("site_area_value", "")
        country = request.POST.get("country", "")
        continent = request.POST.get("continent", "")
        hide = request.POST.get("hide", "")
        is_admin = "1"

        # Store user data in second model
        name = request.POST.get("name", "")
        company_name = request.POST.get("company_name", "")
        phone = request.POST.get("phone", "")
        email = request.POST.get("email", "")

        words = address.split()
        first_few_words = " ".join(words[:3])

        Addproperty = Prperty.objects.create(
            index=index,
            category=category,
            weburl=weburl,
            address=address,
            title=first_few_words,
            image=image,
            purchase_type=purchase_type,
            floor_area=floor_area,
            property_type=property_type,
            Bedroom=Bedroom,
            bathroom=bathroom,
            features=features,
            amenties=amenties,
            duration=duration,
            amount=amount,
            floor_area_value=floor_area_value,
            site_area=site_area,
            site_area_value=site_area_value,
            Country=country,
            Continent=continent,
            hide=hide,
            is_admin=is_admin,
        )

        property_user = Propertyuser.objects.create(
            property_id=Addproperty.id,  # Save the Prperty object's ID
            name=name,
            company_name=company_name,
            phone=phone,
            email=email,
        )

        messages = {"success": "Property has been added."}
        return render(
            request,
            "admin/user/add.html",
            {"messages": messages, "is_superuser": is_superuser},
        )

    messages = {"error": "Property has not been added."}
    return render(
        request,
        "admin/user/add.html",
        {"messages": messages, "is_superuser": is_superuser},
    )


def registeredUser(request):
    user = request.user
    is_superuser = False

    if user.is_authenticated:
        is_superuser = user.is_superuser

    properties_data = CustomUser.objects.all()
    users = CustomUser.objects.filter(is_superuser=0, is_staff=0, is_delete=0)
    index_count = index.objects.all()
    properties = Prperty.objects.all()
    dbcount = database.objects.all().count()
    deleted_users = CustomUser.objects.filter(is_delete=1)
    approved_count = Prperty.objects.filter(is_admin=1).count()


    page = request.GET.get("page", 1)
    properties_per_page = 50

    paginator = Paginator(properties_data, properties_per_page)

    try:
        properties_data_page = paginator.page(page)
    except (PageNotAnInteger, EmptyPage):
        # If page is not an integer or out of range, deliver first page
        properties_data_page = paginator.page(1)

    return render(
        request,
        "admin/user/registeruser.html",
        {
            "users": users,
            "properties_data": properties_data_page,
            "deleted_users": deleted_users,
            "is_superuser": is_superuser,
            "index_count": index_count,
            "properties": properties,
            "dbcount": dbcount,
            "approved_count": approved_count,
        },
    )


def edit_user(request, id):
    user = request.user

    if user.is_authenticated:
        is_superuser = user.is_superuser

    edit = CustomUser.objects.filter(id=id).first()
    properties_data = Prperty.objects.filter(user_id=id).first()
    properties = Prperty.objects.all()
    index_count = index.objects.all()
    users = CustomUser.objects.filter(is_superuser=0)
    dbcount = database.objects.all().count()
    approved_count = Prperty.objects.filter(is_admin=1).count()

    return render(
        request,
        "admin/user/edit.html",
        {
            "edit": edit,
            "is_superuser": is_superuser,
            "properties_data": properties_data,
            "properties": properties,
            "index_count": index_count,
            "users": users,
            "dbcount": dbcount,
            "approved_count" : approved_count,
        },
    )


def update_user(request, id):
    user = request.user

    if user.is_authenticated:
        is_superuser = user.is_superuser

    edit = get_object_or_404(CustomUser, id=id)

    if request.method == "POST":
        first_name = request.POST.get("first_name")
        last_name = request.POST.get("last_name")
        is_active = request.POST.get("is_active")

        edit.first_name = first_name
        edit.last_name = last_name
        edit.is_active = is_active
        edit.save()

        context = {"success": "User  information has been Updated !!"}
        return render(
            request,
            "admin/user/edit.html",
            {"edit": edit, "context": context, "is_superuser": is_superuser},
        )

    context = {"error": "Operation failed !!"}

    return render(
        request,
        "admin/user/edit.html",
        {"edit": edit, "context": context, "is_superuser": is_superuser},
    )


def delete_user(request, id):
    delete = CustomUser.objects.filter(id=id).update(is_delete="1")
    return redirect("registeredUser")


def view_property(request, id):
    user = request.user

    if user.is_authenticated:
        is_superuser = user.is_superuser

    properties_data = Prperty.objects.filter(user_id=id).first()
    properties = Prperty.objects.all()
    index_count = index.objects.all()
    users = CustomUser.objects.filter(is_superuser=0)
    dbcount = database.objects.all().count()
    approved_count = Prperty.objects.filter(is_admin=1).count()


    # if request.method == "POST":
    #     properties.is_admin = request.POST["is_admin"]
    #     properties.save()

    keys_data = None
    features = None
    if properties_data is not None:
        keys_data = properties_data.features
        features = "".join(
            str(elem).replace("[", "").replace("]", "").replace("'", "")
            for elem in keys_data
        )

    keyvalue = None
    amenties = None
    if properties_data is not None:
        keyvalue = properties_data.amenties
        amenties = "".join(
            str(elem).replace("[", "").replace("]", "").replace("'", "")
            for elem in keyvalue
        )

    keypair = None
    property_type = None
    if properties_data is not None:
        keypair = properties_data.property_type
        property_type = "".join(
            str(elem).replace("[", "").replace("]", "").replace("'", "")
            for elem in keypair
        )

    if properties_data is not None:
        properties_data.features = features
        properties_data.amenties = amenties
        properties_data.property_type = property_type

    users_data = Propertyuser.objects.filter(id=id).first()
    return render(
        request,
        "admin/property/viewproperty.html",
        {
            "properties_data": properties_data,
            "users_data": users_data,
            "is_superuser": is_superuser,
            "properties": properties,
            "index_count": index_count,
            "users": users,
            "dbcount": dbcount,
            "approved_count": approved_count,
        },
    )


def AddUser(request):
    user = request.user
    users = CustomUser.objects.filter(is_superuser=0)
    properties = Prperty.objects.all()
    index_count = index.objects.all()
    dbcount = database.objects.all().count()
    approved_count = Prperty.objects.filter(is_admin=1).count()

    if user.is_authenticated:
        is_superuser = user.is_superuser
    return render(
        request,
        "admin/user/adduser.html",
        {
            "is_superuser": is_superuser,
            "users": users,
            "properties": properties,
            "index_count": index_count,
            "dbcount": dbcount,
            "approved_count": approved_count
        },
    )


def ajaxadduser(request):
    user = request.user

    if user.is_authenticated:
        is_superuser = user.is_superuser

    if request.method == "POST":
        first_name = request.POST["first_name"]
        last_name = request.POST["last_name"]
        username = request.POST["username"]
        email = request.POST["email"]
        password1 = make_password(request.POST["password1"])
        CustomUser.objects.create(
            first_name=first_name,
            last_name=last_name,
            username=username,
            email=email,
            password=password1,
        )
        context = {"success": "Successfully updated details !!"}
    # print(amenties )

    # return HttpResponse(result )

    return render(
        request,
        "admin/user/adduser.html",
        {"is_superuser": is_superuser, "context": context},
    )
    context = {"error": "Oops! Something went wrong"}
    return render(
        request,
        "admin/user/adduser.html",
        {"is_superuser": is_superuser, "context": context},
    )


## Database


def Database(request):
    properties_data = database.objects.all()
    properties = Prperty.objects.all()
    users = CustomUser.objects.filter(is_superuser=0)
    index_count = index.objects.all()
    dbcount = database.objects.all().count()
    approved_count = Prperty.objects.filter(is_admin=1).count()

    user = request.user
    is_superuser = user.is_authenticated and user.is_superuser

    page = request.GET.get("page", 1)
    properties_per_page = 50

    paginator = Paginator(properties_data, properties_per_page)

    try:
        properties_data = paginator.page(page)
    except PageNotAnInteger:
        properties_data = paginator.page(1)
    except EmptyPage:
        properties_data = paginator.page(paginator.num_pages)

    return render(
        request,
        "admin/database/database.html",
        {
            "properties_data": properties_data,
            "properties": properties,
            "users": users,
            "is_superuser": is_superuser,
            "index_count": index_count,
            "approved_count": approved_count,
            "dbcount": dbcount,
        },
    )

# def conversion(cov_floor):
#     try:
#         value_floor, unit_floor = cov_floor.split(" ")
#         value_floor = float(value_floor)
#         unit_floor = unit_floor.strip().lower()

#         if unit_floor == "m²":
#             value_floor = square_meters_to_square_feet(value_floor)
#             unit_floor = "ft²"
#         elif unit_floor == "ft²":
#             value_floor = square_feet_to_square_meters(value_floor)
#             unit_floor = "m²"

#         cov_floor = f"{value_floor:.2f} {unit_floor}"
#     except ValueError:
#         # Handle invalid format or conversion errors gracefully
#         pass

#     return cov_floor


def db_edit(request, id):
    user = request.user

    if user.is_authenticated:
        is_superuser = user.is_superuser

    edit = database.objects.filter(property_id=id).first()
    properties_data = Prperty.objects.filter(id=id).first()
    properties = Prperty.objects.all()
    index_count = index.objects.all()
    users = CustomUser.objects.filter(is_superuser=0)
    dbcount = database.objects.all().count()
    approved_count = Prperty.objects.filter(is_admin=1).count()
    
    cov_floor = int(properties_data.floor_area_value)
    floor_area = properties_data.floor_area
    
    cov_site = int(properties_data.site_area_value)
    site_area = properties_data.site_area
    

    if floor_area == "m²":
      sqf = round (cov_floor * 10.7639, 2)
      properties_data.sqf = str(sqf) + " ft²"
    else :
      sqf = round(cov_floor * 0.092903, 2) 
      properties_data.sqf = str(sqf) + " m²"
      
    if site_area == "m²":
      mts = round (cov_site * 10.7639, 2)
      properties_data.mts = str(mts) + " ft²"
    else :
      mts = round(cov_site * 0.092903, 2) 
      properties_data.mts = str(mts) + " m²"
    
    
    return render(
        request,
        "admin/database/db_edit.html",
        {
            "edit": edit,
            "is_superuser": is_superuser,
            "properties_data": properties_data,
            "approved_count" : approved_count,
            "properties": properties,
            "index_count": index_count,
            "users": users,
            "dbcount": dbcount,
            
        },
    )


# def square_meters_to_square_feet(sq_m):
#     # 1 m² = 10.7639 ft²
#     return sq_m * 10.7639


# def square_feet_to_square_meters(sq_ft):
#     # 1 ft² = 0.092903 m²
#     return sq_ft * 0.092903


def db_update(request, id):
    user = request.user
    if user.is_authenticated:
        is_superuser = user.is_superuser
    edit = get_object_or_404(database, id=id)
    properties_data = Prperty.objects.filter(id=id).first()
    properties = Prperty.objects.all()
    index_count = index.objects.all()
    users = CustomUser.objects.filter(is_superuser=0)
    dbcount = database.objects.all().count()
    approved_count = Prperty.objects.filter(is_admin=1).count()


    if request.method == "POST":
        name = request.POST.get("name")
        # date_uploaded = request.Post.get("date_uploaded")
        number = request.POST.get("number")
        street = request.POST.get("street")
        postcode = request.POST.get("postcode")
        city_town = request.POST.get("city_town")
        country = request.POST.get("country")
        continent = request.POST.get("continent")
        # status = request.POST.get("status")
        # status_value = request.POST.get("status_value")
        prop_type = request.POST.get("prop_type")
        features = request.POST.get("features")
        exterior = request.POST.get("exterior")
        interior = request.POST.get("interior")
        energy_efficiency = request.POST.get("energy_efficiency")
        environmental_impact = request.POST.get("environmental_impact")
        riverside = request.POST.get("riverside")
        seaside = request.POST.get("seaside")
        bar = request.POST.get("bar")
        convenience_store = request.POST.get("convenience_store")
        fire_station = request.POST.get("fire_station")
        gym = request.POST.get("gym")
        hospital = request.POST.get("hospital")
        nursery = request.POST.get("nursery")
        park = request.POST.get("park")
        petrol_station = request.POST.get("petrol_station")
        police_station = request.POST.get("police_station")
        restaurant = request.POST.get("restaurant")
        school = request.POST.get("school")
        super_market = request.POST.get("super_market")
        # floor_area = request.POST.get("floor_area")
        # site_area = request.POST.get("site_area")
        kitchen = request.POST.get("kitchen")
        living_room = request.POST.get("living_room")
        bedroom1 = request.POST.get("bedroom1")
        bedroom2 = request.POST.get("bedroom2")
        bedroom3 = request.POST.get("bedroom3")
        bus_stop = request.POST.get("bus_stop")
        airport = request.POST.get("airport")
        train_station = request.POST.get("train_station")
        underground_station = request.POST.get("underground_station")
        sort = request.POST.get("sort")

        edit.name = name
        # edit.date_added = date_uploaded
        edit.number = number
        edit.street = street
        edit.postcode = postcode
        edit.city_town = city_town
        edit.country = country
        edit.continent = continent
        # edit.status = status
        # edit.status_value = status_value
        edit.prop_type = prop_type
        edit.features = features
        edit.exterior = exterior
        edit.interior = interior
        edit.energy_efficiency = energy_efficiency
        edit.environmental_impact = environmental_impact
        edit.riverside = riverside
        edit.seaside = seaside
        edit.bar = bar
        edit.convenience_store = convenience_store
        edit.fire_station = fire_station
        edit.gym = gym
        edit.hospital = hospital
        edit.nursery = nursery
        edit.park = park
        edit.petrol_station = petrol_station
        edit.police_station = police_station
        edit.restaurant = restaurant
        edit.school = school
        edit.super_market = super_market
        # edit.floor_area = floor_area
        # edit.site_area = site_area
        edit.kitchen = kitchen
        edit.living_room = living_room
        edit.bedroom1 = bedroom1
        edit.bedroom2 = bedroom2
        edit.bedroom3 = bedroom3
        edit.bus_stop = bus_stop
        edit.airport = airport
        edit.train_station = train_station
        edit.underground_station = underground_station
        edit.sort = sort

        edit.save()
        
        context = {"success": "Property  information has been Updated !!"}
        return render(
            request,
            "admin/database/db_edit.html",
            {
                "edit": edit,
                "context": context,
                "is_superuser": is_superuser,
                "properties_data": properties_data,
                "properties": properties,
                "index_count": index_count,
                "users": users,
                "dbcount": dbcount,
                "approved_count": approved_count,
            },
        )

    context = {"error": "Operation failed !!"}

    return render(
        request,
        "admin/database/db_edit.html",
        {
            "edit": edit,
            "context": context,
            "is_superuser": is_superuser,
            "properties_data": properties_data,
            "properties": properties,
            "index_count": index_count,
            "users": users,
            "dbcount": dbcount,
            "approved_count":approved_count,
        },
    )


##Ratings
def rating(request):
    user = request.user
    users = CustomUser.objects.filter(is_superuser=0)
    properties = Prperty.objects.all()
    index_count = index.objects.all()
    dbcount = database.objects.all().count()
    properties_data = Rating.objects.all()
    is_admin_rating = Rating.objects.filter(admin_id=user.id).first()
    ratings = Rating.objects.all()
    approved_count = Prperty.objects.filter(is_admin=1).count()

    
    # for rating in ratings:
    #     if is_admin_rating:
    #         rating.interior_rating = is_admin_rating.interior
    #         rating.exterior_rating = is_admin_rating.exterior
    # else:
    #     # If the user doesn't have a rating, you might want to set default values or handle it accordingly.
    #     rating.interior_rating = 0
    #     rating.exterior_rating = 0

    # if user.is_authenticated:
    #     is_superuser = user.is_superuser

    is_superuser = user.is_authenticated and user.is_superuser

    page = request.GET.get("page", 1)
    properties_per_page = 50

    paginator = Paginator(properties_data, properties_per_page)

    try:
        properties_data = paginator.page(page)
    except PageNotAnInteger:
        properties_data = paginator.page(1)
    except EmptyPage:
        properties_data = paginator.page(paginator.num_pages)

    return render(
        request,
        "admin/rating/rating.html",
        {
            "is_superuser": is_superuser,
            "users": users,
            "properties": properties,
            "ratings": ratings,
            "index_count": index_count,
            "dbcount": dbcount,
            "properties_data": properties_data,
            "approved_count": approved_count
        },
    )


def rating_edit(request, property_id):
    user = request.user

    if user.is_authenticated:
        is_superuser = user.is_superuser

    edit = Rating.objects.get(property_id=property_id)
    properties_data = Prperty.objects.filter(user_id=id).first()
    properties = Prperty.objects.all()
    index_count = index.objects.all()
    users = CustomUser.objects.filter(is_superuser=0)
    dbcount = database.objects.all().count()
    approved_count = Prperty.objects.filter(is_admin=1).count()

    return render(
        request,
        "admin/rating/rating_edit.html",
        {
            "edit": edit,
            "is_superuser": is_superuser,
            "properties_data": properties_data,
            "properties": properties,
            "index_count": index_count,
            "users": users,
            "dbcount": dbcount,
            "approved_count" : approved_count,
        },
    )


def rating_update(request, property_id):
    user = request.user

    if user.is_authenticated:
        is_superuser = user.is_superuser

    edit = Rating.objects.get(property_id=property_id)
    properties_data = Prperty.objects.filter(user_id=id).first()
    properties = Prperty.objects.all()
    index_count = index.objects.all()
    users = CustomUser.objects.filter(is_superuser=0)
    dbcount = database.objects.all().count()
    Ratings = Rating.objects.filter(admin_id=user.id).first()
    approved_count = Prperty.objects.filter(is_admin=1).count()


    if request.method == "POST":
        interior = request.POST.get("interior")
        exterior = request.POST.get("exterior")

    if Ratings:
        Ratings.interior = interior
        Ratings.exterior = exterior
        Ratings.save()
    else:
        # Handle the case when there is no Ratings object for the property
        Rating.objects.create(
            admin_id=user.id,
            interior=interior,
            exterior=exterior,
            property_id=property_id,
        )
    context = {"success": " Ratings has been Updated !!"}
    return render(
        request,
        "admin/rating/rating_edit.html",
        {
            "edit": edit,
            "context": context,
            "is_superuser": is_superuser,
            "properties_data": properties_data,
            "properties": properties,
            "index_count": index_count,
            "users": users,
            "dbcount": dbcount,
            "approved_count": approved_count
        },
    )


def approve(request, id):
    user = request.user

    if user.is_authenticated:
        is_superuser = user.is_superuser

    prperty = get_object_or_404(Prperty, id=id)
    prperty.is_admin = 1
    current_datetime = datetime.now()
    formatted_datetime = current_datetime.strftime("%H:%M, %d/%m/%Y")
    parsed_datetime = datetime.strptime(formatted_datetime, "%H:%M, %d/%m/%Y")
    user_id = prperty.user_id
    floor_area_combined = f"{prperty.floor_area_value} {prperty.floor_area}"
    site_area_combined = f"{prperty.site_area_value} {prperty.site_area} "
    prperty.save()

    features = "".join(
        str(elem).replace("[", "").replace("]", "").replace("'", "")
        for elem in prperty.features
    )

    prop_type = "".join(
        str(elem).replace("[", "").replace("]", "").replace("'", "")
        for elem in prperty.property_type
    )

    Addproperty = database.objects.create(
        name=prperty.title,
        date_uploaded=prperty.created_at,
        date_approved=parsed_datetime,
        city_town=prperty.address,
        country=prperty.Country,
        continent=prperty.Continent,
        status=prperty.purchase_type,
        status_value=prperty.amount,
        prop_type=prop_type,  # Use the modified prop_type variable
        features=features,  # Use the modified features variable
        floor_area=floor_area_combined,
        site_area=site_area_combined,
        link=prperty.weburl,
        property_id=id,
    )

    admin_id = user.id
    property_id = id

    Rating.objects.create(
        admin_id=admin_id,
        name=prperty.title,
        date_added=prperty.created_at,
        link=prperty.weburl,
        property_id=id,
    )

    return redirect("view_property", user_id)


def unapprove(request, id):
    prperty = get_object_or_404(Prperty, id=id)
    prperty.is_admin = 0
    user_id = prperty.user_id
    prperty.save()

    # Delete the corresponding entry from the 'database' table
    database.objects.filter(property_id=id).delete()
    Rating.objects.filter(property_id=id).delete()

    return redirect("view_property", user_id)
