import ast
from django.shortcuts import render
from polls.models import index ,category,Contact, Prperty, Propertyuser,CustomUser
from django.contrib import messages
from django.shortcuts import redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.hashers import make_password
from django.http import HttpResponseRedirect, HttpResponse, JsonResponse

from django.contrib.sites.shortcuts import get_current_site  
from django.utils.encoding import force_bytes#, force_text 
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode  
from django.template.loader import render_to_string  
from .token import account_activation_token  
from django.core.mail import EmailMessage 
from datetime import date
from datetime import date, timedelta
from datetime import datetime
from django.db.models import Q
from collections import Counter
import random



# User Registration____________________________________________________________________

def email_registration(request):  
    if request.method == 'POST': 
        rand_num = random.randrange(1000, 9000) 
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        email = request.POST['email']
        password1 = make_password(request.POST['password1'])
        opt=rand_num
        user =  CustomUser.objects.create(first_name=first_name, last_name=last_name, username=username, email=email, password=password1, opt=opt)       
        user.is_active = False
        user.save()

        current_site = get_current_site(request)  
        mail_subject = 'Welcome to the linktoscale Web Application' 
        message = render_to_string('acc_active_email.html', {  
            'user': user,  
            'domain': current_site.domain,  
            'uid':urlsafe_base64_encode(force_bytes(user.pk)), 
            'opt': rand_num
            # 'uid': urlsafe_base64_encode(force_bytes(user.pk)).decode(), 
            # 'token':account_activation_token.make_token(user), 
        })  
        to_email = email 
        email = EmailMessage(  
                    mail_subject, message, to=[to_email]  
        )  
        email.send()  
        return render(request,  'otp.html',{'user':user})  
    else:         
        return render(request, 'signup.html') 


def activate(request): 
    if request.method == 'POST':
        username = request.POST.get('username')  # Get the email from the POST data
        opt = request.POST.get('opt')

        user = CustomUser.objects.filter(username=username, opt=opt).first()
        if user:
            user.is_active = True
            user.save()
            return render(request,  'login.html') 
        else:
            context = {'error': 'Wrong OTP'}
            return redirect(request,  'otp.html',{'context': context}) 
    else:
        return redirect('/activate')



def register_request(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        email = request.POST['email']
        password1 = make_password(request.POST['password1'])
        CustomUser.objects.create(first_name=first_name, last_name=last_name, username=username, email=email, password=password1)
        messages.success(request, 'Data has been submitted')

    return render(request, 'signup.html')

def login_request(request):
    if request.method == 'POST':
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')

        user = authenticate(request, username=username, password=password)
        if user is not None and user.is_active and user.is_delete == 0:
            login(request, user)
            return redirect('/')
        else:
            context = {'error': 'Please enter valid credentials'}
            return render(request, 'login.html', {'context': context})

    return render(request, 'login.html')




#frontend functions____________________________________________________________________
# def filter_data(request):
#     if request.method == 'POST':
#         date = request.POST.get('date')
#         continent = request.POST.get('continent')
#         country = request.POST.get('country')
#         city = request.POST.get('city')
#         status = request.POST.get('status')
#         property_type = request.POST.get('property_type')
#         features = request.POST.get('feature')
#         amenities = request.POST.get('amenities')
#         website = request.POST.get('site')

#         # Create an empty dictionary to store the filter parameters
#         filters = {}

#         # Add the filter parameters only if they are not empty
#         # if date:
#         #     filters['date'] = date
#         # if continent:
#         #     filters['continent'] = continent
#         if date:
#             filters.update({'date': date})
#         if continent:
#             filters.update({'continent': continent})
#         if country:
#             filters.update({'address__icontains': country})
#         if city:
#             filters.update({'city': city})
#         if status:
#             filters.update({'purchase_type': status})
#         if property_type:
#             filters.update({'property_type': property_type})
#         if features:
#             filters.update({'features__icontains': features})
#         if amenities:
#             filters.update({'amenties__icontains': amenities})
#         if website:
#             filters.update({'weburl': weburl})

#         # Use the filter parameters to query the database
#         filtered_data = Prperty.objects.filter(**filters)##.extra(where=["purchase_type = %s"], params=[status])

#         # Pass the filtered data to the template for rendering
#         return render(request, 'filtered.html', {'filtered_data': filtered_data})

#     return render(request, 'filtered.html')



#-----------------------Backend validation for fields------------------------------------------->>>
# def Addproperty(request):
#     if request.method == 'POST':
#         index = request.POST.get('index', '')
#         category = request.POST.get('category', '')
#         weburl = request.POST.get('weburl', '')
#         address = request.POST.get('address', '')
#         image = request.FILES.get('image')
#         purchase_type = request.POST.get('purchase_type', '')
#         floor_area = request.POST.get('floor_area', '')
#         property_type = request.POST.getlist('property_type')
#         bedroom = request.POST.get('bedroom', '')
#         bathroom = request.POST.get('bathroom', '')
#         amenities = request.POST.getlist('amenities')
#         features = request.POST.getlist('features')
#         duration = request.POST.get('duration', '')
#         amount = request.POST.get('amount', '')
#         floor_area_value = request.POST.get('floor_area_value', '')
#         site_area = request.POST.get('site_area', '')
#         site_area_value = request.POST.get('site_area_value', '')
#         country = request.POST.get('country', '')
#         continent = request.POST.get('continent', '')
#         hide = request.POST.get('hide', '')
#         is_admin = '0'

#         name = request.POST.get('name', '')
#         company_name = request.POST.get('company_name', '')
#         phone = request.POST.get('phone', '')
#         email = request.POST.get('email', '')

#         # Validation
#         errors = {}

#         if not index:
#             errors['index'] = 'Please provide an index.'

#         if not category:
#             errors['category'] = 'Please select a category.'

#         if not weburl:
#             errors['weburl'] = 'Please provide a web URL.'

#         if not address:
#             errors['address'] = 'Please provide an address.'

#         if not image:
#             errors['image'] = 'Please select an image.'

#         if not purchase_type:
#             errors['purchase_type'] = 'Please select a purchase type.'

#         if not floor_area:
#             errors['floor_area'] = 'Please provide a floor area.'

#         if not property_type:
#             errors['property_type'] = 'Please select at least one property type.'

#         if not bedroom:
#             errors['bedroom'] = 'Please provide the number of bedrooms.'

#         if not bathroom:
#             errors['bathroom'] = 'Please provide the number of bathrooms.'

#         if not amenities:
#             errors['amenities'] = 'Please select at least one amenity.'

#         if not features:
#             errors['features'] = 'Please select at least one feature.'

#         if not duration:
#             errors['duration'] = 'Please provide a duration.'

#         if not amount:
#             errors['amount'] = 'Please provide an amount.'

#         if not floor_area_value:
#             errors['floor_area_value'] = 'Please provide a floor area value.'

#         if not site_area:
#             errors['site_area'] = 'Please provide a site area.'

#         if not site_area_value:
#             errors['site_area_value'] = 'Please provide a site area value.'

#         if not country:
#             errors['country'] = 'Please provide a country.'

#         if not continent:
#             errors['continent'] = 'Please provide a continent.'

#         if not name:
#             errors['name'] = 'Please provide a name.'

#         if not company_name:
#             errors['company_name'] = 'Please provide a company name.'

#         if not phone:
#             errors['phone'] = 'Please provide a phone number.'

#         if not email:
#             errors['email'] = 'Please provide an email address.'

#         if errors:
#             # If there are validation errors, render the form with the errors
#             return render(request, 'upload.html', {'errors': errors})

#         # Create Propertyuser object
#         property_user = Propertyuser.objects.create(
#             name=name,
#             company_name=company_name,
#             phone=phone,
#             email=email,
#         )

#         # Create Prperty object
#         words = address.split()
#         first_few_words = ' '.join(words[:3])
#         Addproperty = Prperty.objects.create(
#             user_id=property_user.id,
#             index=index,
#             category=category,
#             weburl=weburl,
#             address=address,
#             title=first_few_words,
#             image=image,
#             purchase_type=purchase_type,
#             floor_area=floor_area,
#             property_type=property_type,
#             bedroom=bedroom,
#             bathroom=bathroom,
#             features=features,
#             amenities=amenities,
#             duration=duration,
#             amount=amount,
#             floor_area_value=floor_area_value,
#             site_area=site_area,
#             site_area_value=site_area_value,
#             Country=country,
#             Continent=continent,
#             hide=hide,
#             is_admin=is_admin,
#         )

#         messages.success(request, 'Data has been submitted')
#         return redirect('/residential')

#     return render(request, 'upload.html')

#------------------some fields validation is not working------------------------>>
#-----------------------Backend Validation------------------------------------------->>

# def Addproperty(request):
#     # print(request.POST.get('index', ''))
#     # return HttpResponse(request.POST.get('index', ''))

#     if request.method == 'POST':
#         index = request.POST.get('index', '')
#         category = request.POST.get('category', '')  # Assign a value to category
#         weburl = request.POST.get('weburl', '')
#         address = request.POST.get('address', '')
#         # title = request.POST.get('title', '')
#         image = request.FILES['image']
#         purchase_type = request.POST.get('purchase_type', '')
#         floor_area = request.POST.get('floor_area', '')
#         property_type = request.POST.getlist('property_type', '')
#         Bedroom = request.POST.get('Bedroom', '')
#         bathroom = request.POST.get('bathroom', '')
#         amenties = request.POST.getlist('amenties')
#         features = request.POST.getlist('features')
#         duration = request.POST.get('duration', '')
#         amount = request.POST.get('amount', '')
#         floor_area_value = request.POST.get('floor_area_value', '')
#         site_area = request.POST.get('site_area', '')
#         site_area_value = request.POST.get('site_area_value', '')
#         country = request.POST.get('country','')
#         continent = request.POST.get('continent','')
#         hide = request.POST.get('hide', '')
#         is_admin = '0'

#         # Store user data in second model
#         name = request.POST.get('name', '')
#         company_name = request.POST.get('company_name', '')
#         phone = request.POST.get('phone', '')
#         email = request.POST.get('email', '')

#         words = address.split()
#         first_few_words = ' '.join(words[:3])




#         property_user = Propertyuser.objects.create(
#             name=name,
#             company_name=company_name,
#             phone=phone,
#             email=email,
#         )

#         Addproperty = Prperty.objects.create(
#             user_id= property_user.id,
#             index=index,
#             category=category,
#             weburl=weburl,
#             address=address,
#             title=first_few_words,
#             image=image,
#             purchase_type=purchase_type,
#             floor_area=floor_area,
#             property_type=property_type,
#             Bedroom=Bedroom,
#             bathroom=bathroom,
#             features=features,
#             amenties=amenties,
#             duration=duration,
#             amount=amount,
#             floor_area_value=floor_area_value,
#             site_area=site_area,
#             site_area_value=site_area_value,
#             Country=country,
#             Continent=continent,
#             hide=hide,
#             is_admin=is_admin,
            
#         )
        

#         # property_user.Prperty = Addproperty  # Associate with Prperty object
#         # property_user.save()  # Save the created object

#         messages.success(request, 'Data has been submitted')

#         return redirect('/residential')

#     return render(request, 'upload.html')

#------------------------------>>>>>------------------------------
def Addproperty(request):
    if request.method == 'POST':
            index = request.POST.get('index', '')
            category = request.POST.get('category', '')
            weburl = request.POST.get('weburl', '')
            address = request.POST.get('address', '')
            image = request.FILES.get('image', '')
            purchase_type = request.POST.get('purchase_type', '')
            floor_area = request.POST.get('floor_area', '')
            property_type = request.POST.getlist('property_type')
            Bedroom = request.POST.get('Bedroom', '')
            bathroom = request.POST.get('bathroom', '')
            amenties = request.POST.getlist('amenties')
            features = request.POST.getlist('features')
            duration = request.POST.get('duration', '')
            amount = request.POST.get('amount', '')
            floor_area_value = request.POST.get('floor_area_value', '')
            site_area = request.POST.get('site_area', '')
            site_area_value = request.POST.get('site_area_value', '')
            country = request.POST.get('country', '')
            continent = request.POST.get('continent', '')
            hide = request.POST.get('hide', '')
            is_admin = '0'

            name = request.POST.get('name', '')
            company_name = request.POST.get('company_name', '')
            phone = request.POST.get('phone', '')
            email = request.POST.get('email', '')
            words = address.split()
            first_few_words = ' '.join(words[:3])

            property_user = Propertyuser.objects.create(
                name=name,
                company_name=company_name,
                phone=phone,
                email=email,
            )

            Addproperty = Prperty.objects.create(
                user_id=property_user.id,
                index=index,
                category=category,
                weburl=weburl,
                address=address,
                title=first_few_words,
                image=image,
                purchase_type=purchase_type,
                floor_area=floor_area,
                property_type=property_type,
                Bedroom=Bedroom,
                bathroom=bathroom,
                features=features,
                amenties=amenties,
                duration=duration,
                amount=amount,
                floor_area_value=floor_area_value,
                site_area=site_area,
                site_area_value=site_area_value,
                Country=country,
                Continent=continent,
                hide=hide,
                is_admin=is_admin,
            )

            # Check if there are additional listings
            listing_counter = int(request.POST.get('listingCounter', 0))
            for i in range(2, listing_counter + 1):
                index = request.POST.get(f'index{i}', '')
                category = request.POST.get(f'category{i}', '')
                weburl = request.POST.get(f'weburl{i}', '')
                address = request.POST.get(f'address{i}', '')
                image = request.FILES.get(f'image{i}', '')
                purchase_type = request.POST.get(f'purchase_type{i}', '')
                floor_area = request.POST.get(f'floor_area{i}', '')
                property_type = request.POST.getlist(f'property_type{i}', [])
                Bedroom = request.POST.get(f'Bedroom{i}', '')
                bathroom = request.POST.get(f'bathroom{i}', '')
                amenties = request.POST.getlist(f'amenties{i}', [])
                features = request.POST.getlist(f'features{i}', [])
                duration = request.POST.get(f'duration{i}', '')
                amount = request.POST.get(f'amount{i}', '')
                floor_area_value = request.POST.get(f'floor_area_value{i}', '')
                site_area = request.POST.get(f'site_area{i}', '')
                site_area_value = request.POST.get(f'site_area_value{i}', '')
                country = request.POST.get(f'country{i}', '')
                continent = request.POST.get(f'continent{i}', '')
                hide = request.POST.get(f'hide{i}', '')
                is_admin = '0'

                Addproperty=Prperty.objects.create(
                    user_id=property_user.id,
                    index=index,
                    category=category,
                    weburl=weburl,
                    address=address,
                    title=first_few_words,
                    image=image,
                    purchase_type=purchase_type,
                    floor_area=floor_area,
                    property_type=property_type,
                    Bedroom=Bedroom,
                    bathroom=bathroom,
                    features=features,
                    amenties=amenties,
                    duration=duration,
                    amount=amount,
                    floor_area_value=floor_area_value,
                    site_area=site_area,
                    site_area_value=site_area_value,
                    Country=country,
                    Continent=continent,
                    hide=hide,
                    is_admin=is_admin,
                )

            messages.success(request, 'Data has been submitted')
            return redirect('/submit')
    else:
        # form = LoginForm()
     return render(request, 'testing_upload.html')


#------------------------------<<<<<-------------------------------
def submit(request):
    return render(request, 'submit.html')

def wrongotp(request):
    return render(request,'otp.html')

def contact(request):
    if request.method=='POST':
        full_name=request.POST['full_name']
        email=request.POST['email']
        message=request.POST['message']
        contact=Contact.objects.create(full_name=full_name,email=email,message=message)
        messages.success(request,'Data has been submitted')
    return render(request,'contact.html')
    

def home(request):
	st=index.objects.all() # Collect all records from table 
	return render(request,'home.html',{'st':st})



def category_view(request, sts_id):
    cat = category.objects.filter(index_id=sts_id)
    return render(request, 'property.html', {'cat': cat})

	
def how_it_works(request):
    return render(request,'how_it_works.html')

def help(request):
    return render(request,'help.html')

def settings(request):
    return render(request,'settings.html')

def upload(request):
    return render(request,'testing_upload.html')

def property(request):
    return render(request,'property.html',{'st':st})

def vehicles(request):
    return render(request,'vehicles.html')

# def residential(request):
#     properties = Prperty.objects.filter(index=1, category=1, is_admin=1)
    
#     for property in properties:
#         if property.hide == "on":
#             ini_string = property.title
#             property.title = ''.join([i for i in ini_string if not i.isdigit()])

#     return render(request, 'residential.html', {'properties': properties})

def subcategory(request):
    return render(request,'sub-category.html')
    
def userlogin(request):
    return render(request, 'login.html')

def signup(request):
    return render(request, 'signup.html') 

def residential(request):
    if is_ajax(request): 
        status = request.GET.get("status", '')
        purchase_type=status
        property_type = request.GET.get("property_type", '')
        country = request.GET.get("country", '')
        features = request.GET.get("features", '')
        amenities = request.GET.get("amenities", '')
        duration = request.GET.get("duration", '')
        bedrooms = request.GET.get("bedrooms", '')
        created_at= request.GET.get("created_at", '')
        continent= request.GET.get("continent", '')
        city = request.GET.get("city", '')
        price = request.GET.get("price", '')
        bathroom = request.GET.get("bathroom", '')
        index=1
        category=1
        is_admin=1
        filters = {}

        if bedrooms:
           num_bedrooms = int(bedrooms)
        

        if created_at:
            days =int(created_at)
            
            today =  datetime.now()#date.today() 
        
            past_date = today - timedelta(days=days)

        # print(bedroom_range)
        # return HttpResponse(bedroom_range)
     

   
        if duration:
            filters.update({'date_f': duration})
        if country:
            filters.update({'Country__icontains': country})
        if purchase_type:
            filters.update({'purchase_type': purchase_type})
        if property_type:
            filters.update({'property_type': property_type})
        if features:
            filters.update({'features__icontains': features})
        if amenities:
            filters.update({'amenties__icontains': amenities})  
        if index:      
            filters.update({'index': index})
        if category:      
            filters.update({'category': category}) 
        if bedrooms:      
            filters.update({'Bedroom__lte':num_bedrooms})   
        if bathroom:      
            filters.update({'bathroom__lte':bathroom})     
        if is_admin:       
            filters.update({'is_admin': is_admin}) 
        if continent:       
            filters.update({'Continent': continent})  
        if city:       
            filters.update({'address__icontains': city})   
        if price:       
             filters.update({'amount__lte':price})     
        if created_at:
            filters.update({'created_at__gte': past_date})
            # filters['created_at__gte'] = past_date

        properties = Prperty.objects.filter(**filters)
   
        # print(properties)
        # return HttpResponse(properties)
    
        property_list = []
        for property in properties:
             if property.hide == "on":
              ini_string = property.title
              
              title = ''.join([i for i in ini_string if not i.isdigit()])
             else: 
              title = property.title  
              property_list.append({
                 'id': property.id,
                 'title': title,
                 'image': property.image.url,
                 'weburl': property.weburl,
                })
    
        return JsonResponse({'properties': property_list})   
    else: 
         properties = Prperty.objects.filter(index=1, category=1, is_admin=1)

         asia = Prperty.objects.filter(is_admin=1, Continent__exact='Asia').count()
         europe = Prperty.objects.filter(is_admin=1, Continent__exact='Europe').count()
         africa = Prperty.objects.filter(is_admin=1, Continent__exact='Africa').count()
         antractica = Prperty.objects.filter(is_admin=1, Continent__exact='Antractica').count()
         north_america = Prperty.objects.filter(is_admin=1, Continent__exact='North America').count()
         south_america = Prperty.objects.filter(is_admin=1, Continent__exact='South America').count()
         australia = Prperty.objects.filter(is_admin=1, Continent__exact='Australia').count()
         data_records = Prperty.objects.all()
         type_counter = Counter()
         feature_counter = Counter()
         amenities_counter = Counter()
         country_counter = Counter()
        #  initial_count ={'0': 0, '1': 0, '2': 0}
         initial_count = {'0': 0, '1': 0, '2': 0, '3': 0, '4': 0}
         for record in data_records:
            type_list = ast.literal_eval(record.property_type)  
            type_counter.update(type_list)

         for record in data_records:
            feature_list = ast.literal_eval(record.features)  
            feature_counter.update(feature_list)

         for record in data_records:
            amenities_list = ast.literal_eval(record.amenties)  
            amenities_counter.update(amenities_list)   

         for record in data_records:
            status = record.purchase_type  
            initial_count[status] += 1
        
        #  for record in data_records:
        #     status = str(record.purchase_type)  # Convert to string to match dictionary keys
        #     if status in initial_count:
        #         initial_count[status] += 1
        
         for record in data_records:
            country_name = record.Country  # Replace 'country' with the actual field name in your model
            country_counter.update([country_name])   

    status_labels = {'0': 'Rent', '1': 'Buy', '2': 'Auction', '3': 'Stay', '4': 'Featured'}  
    type_count = [{'value': value, 'count': count} for value, count in type_counter.items()]
    feature_count = [{'value': value, 'count': count} for value, count in feature_counter.items()]
    amenities_count = [{'value': value, 'count': count} for value, count in amenities_counter.items()]
    status_count = [{'value': status, 'label': status_labels[status], 'count': count} for status, count in initial_count.items()]
    country_counts = [{'value': value, 'count': count} for value, count in country_counter.items()]
                                       
    for property in properties:
          if property.hide == "on":
            ini_string = property.title
            property.title = ''.join([i for i in ini_string if not i.isdigit()])


          return render(request, 'testfilter.html', {'country_counts': country_counts,'status_count': status_count,'amenities_count': amenities_count,'feature_count': feature_count,'type_count': type_count,'properties': properties, 'asia': asia, 'europe':europe, 'africa':africa, 'antractica':antractica, 'north_america':north_america, 'south_america':south_america, 'australia':australia})
  

def is_ajax(request):
    return request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'

def UploadProperty(request):
    return render(request, 'add_property.html')

def testform(request):
    return render(request, 'testform.html')

        




